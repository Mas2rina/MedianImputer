#' Median Imputer Function
#'
#' This function replaces NA values in a numeric vector with the median of the non-NA values.
#'
#' @param x A numeric vector with potential NA values.
#' @return A numeric vector with NA values replaced by the median of non-NA values.
#' @examples
#' # Example usage
#' x <- c(1, NA, 3, NA, 5)
#' median_impute(x)
etect_data <- function(dataset){
  numeric_data <- dataset[sapply(dataset,is.numeric)]

  medians <- sapply(numeric_data, median, na.rm=TRUE)

  for(i in names(numeric_data)){
    dataset[[i]][is.na(dataset[[i]])] <- medians[[i]]
  }

  return(dataset)

}

